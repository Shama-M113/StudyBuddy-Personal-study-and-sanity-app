package com.example.madaat

import android.support.v7.app.AppCompatActivity
import android.os.Bundle
import android.widget.TextView
import android.content.Intent
import android.widget.Button

class signuppage : AppCompatActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_signuppage)
        val loginLink = findViewById<TextView>(R.id.loginLink)
        loginLink.setOnClickListener {
            val intent = Intent(this, MainActivity::class.java)
            startActivity(intent)
            finish() // Optional
        }
        val btn=findViewById<Button>(R.id.button2)
        btn.setOnClickListener {
            val intent = Intent(this, HomeDashboard::class.java)
            startActivity(intent)
            finish() // Optional
        }


    }
}