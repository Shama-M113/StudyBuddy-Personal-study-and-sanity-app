package com.example.madaat

import android.content.Intent
import android.support.v7.app.AppCompatActivity
import android.os.Bundle
import android.widget.Button
import android.widget.TextView
import kotlin.math.sign

class MainActivity : AppCompatActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_main)
        val loginLink = findViewById<TextView>(R.id.signin)
        loginLink.setOnClickListener {
            val intent = Intent(this, signuppage::class.java)
            startActivity(intent)
            finish() // Optional
        }

        val btn = findViewById<Button>(R.id.button)
        btn.setOnClickListener {
            val intent = Intent(this, HomeDashboard::class.java)
            startActivity(intent)
            finish() // Optional
        }
    }

}