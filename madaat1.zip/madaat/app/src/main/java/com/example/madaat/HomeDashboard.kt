package com.example.madaat

import android.annotation.SuppressLint
import android.content.Intent
import android.support.v7.app.AppCompatActivity
import android.os.Bundle
import android.provider.ContactsContract.CommonDataKinds.Im
import android.widget.ImageView
import android.widget.TextView

class HomeDashboard : AppCompatActivity() {

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_home_dashboard)
         val scheduler=findViewById<ImageView>(R.id.schedule)
        scheduler.setOnClickListener{
            val intent = Intent(this, smartscheduler::class.java)
            startActivity(intent)
             // Option
        }

        val doubt=findViewById<ImageView>(R.id.doubt)
        doubt.setOnClickListener {
            val intent = Intent(this, doubtsolver::class.java)
            startActivity(intent)
           // Option
        }
        val progress=findViewById<TextView>(R.id.progress)
        progress.setOnClickListener {
            val intent = Intent(this, progresstracker::class.java)
            startActivity(intent)
            // Option
        }
        val focus=findViewById<ImageView>(R.id.focus)
        focus.setOnClickListener {
            val intent = Intent(this, FocusMode::class.java)
            startActivity(intent)
            // Option
        }
        val emotion=findViewById<ImageView>(R.id.emotion)
        emotion.setOnClickListener {
            val intent = Intent(this, Emotion::class.java)
            startActivity(intent)
            // Option
        }

    }
}